#include <stdio.h>

#define N 10
int n = 10;
int r = 10;


main(void) {


int A[N][N], B[N][N], C[N][N],a, b, c, d;

printf("Matrix A:\n");

A[N][N]= Matrix(A);

a = n;

b = r;

printf("Matrix B:\n");

 B[N][N]= Matrix(B);

 c = n;

 d = r;



 if (a == d || b == c) {

	 if (a == d) {
		 a = d;
	 }
	 if (b == c) {
		 b == c;
	 }

	 Mult(A, B, C, a,d);

 }
 else {

	 printf("AB is undefined");
 }


  int M=0;

  scanf_s("%d", M);
}
void getRowandCol(int a, int b) {

	n = a;
	r = b;

	}

	int Matrix(int m[N][N]) {
	
		int a, b;



		printf("Enter number of rows for Matrix: ");


		scanf_s("%d", &a);

	

		printf("Enter number of columns for Matrix: ");

		scanf_s("%d", &b);

		getRowandCol(a,b);

		for (int c = 0; c < a; c++) {

			printf("Enter Row %d of Matrix: ", c + 1);

			for (int d = 0; d < b; d++) {

				scanf_s("%d", &m[c][d]);


			}

		}
		

		


		return m;
		
		
	}

	int Mult(int k[N][N], int j[N][N],int L[N][N],int c, int d) {
		
		int a, b;
		
				
					int sum;
		
					for (a = 0; a < c; a++)
					{
						

						for (b =0 ; b < d; b++)
						{
							sum = 0;

							for (int c = 0; c < N; c++) {

									sum = sum + k[a][c] * j[c][b];


								if (sum < N*N*N && sum > -(N*N*N)) {

									L[a][b] = sum;
								}
								
							}
							
							
						}
						
					}


					printf("AB is: \n");

					for (a = 0; a < N; a++)
					{
						for (b = 0; b < N; b++)

							if (L[a][b] < N*N*N && L[a][b] > -(N*N*N)) {
								printf("%d  ", L[a][b]);
								
							}
						printf("\t\n");
						
			
					}
							
		
		return L;
	}

	

		