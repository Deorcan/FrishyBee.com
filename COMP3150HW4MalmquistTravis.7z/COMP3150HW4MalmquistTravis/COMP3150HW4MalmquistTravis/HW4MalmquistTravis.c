														//Travis Malmquist
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>




#define SIZE 80

FILE *ptr;
int main(void) {



	int choice=0;

	printf("Manual:\n Enter 1 to read from standard input, "	//manual
          "Enter 2 to read and write from a file ");

	scanf_s("%d", &choice);

	if (choice == 1) {

		int b=0;

		char sentence[SIZE]; // create char array
					

		ptr = fopen("TextFile.txt", "w");

			

		int fputs(const sentence, FILE *ptr );  

		printf("Enter a line of text (enter / to exit text): ");
		

		
		scanf("%[^/]s", sentence);	//scans till / is entered
		
		
		


		fputs(sentence, ptr);
		
		
		



		printf("Your text is: %s, Enter * to end",sentence);


		scanf("%[^*]s", sentence); //debugging..
	}

	else if (choice == 2) {



		

		// creating a character variable
		 char sentence[SIZE];
		char C='c';
		int c=0;
		char File [SIZE];
		int i=0;

		printf("Enter a file: ");

		scanf("%s", File); 


		// open the file in write mode
		ptr = fopen(File, "w");

		// take user input
		printf("Enter a line of text (enter / to exit) : ");

		scanf("%[^/]s", sentence);





		fputs(sentence, ptr);
		
		fclose(ptr);

		ptr = fopen(File, "r");
			
		printf("The contents of %s file are:",File);

		C = fgetc(ptr);

		while (C != EOF)
		{
			printf("%c", C);
			C = fgetc(ptr);
			
		}
		fclose(ptr);

		printf("Enter * to close...");
		scanf("%[^*]s", sentence);
	}


	else {
		printf("Unapplicable Keyword!");
	}


}