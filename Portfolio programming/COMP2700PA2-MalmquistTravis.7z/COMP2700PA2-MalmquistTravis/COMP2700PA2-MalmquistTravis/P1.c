#include <stdio.h>
#include <math.h>
int a = 0;
int b = 0;
int s = 0;
int t = 0;
int x = 0;
int y = 0;
int w = 0;
int z = 0;
int gcd = 0;
int c = 0;

void GCD();
void BCoeff();

void main() {

	printf("First integer: ");

	scanf_s("%d", &a);

	printf("\nSecond integer: ");

	scanf_s("%d", &b);

	system("cls");

	GCD();

	BCoeff();

	gcd = _getch();

}

void GCD() {

	for (int i = a; i > 1; i--) {

		for (int j = b; j > 1; j--) {

			x = a / i;
			y = b / j;

			if (x > w || y > z) {

				w = x;

				z = y;

				
			}

		

			if (w == z) {



				gcd = w;

				
			}
			

		}

	}
	printf("The GCD is: %d\n", gcd);
}

void BCoeff() {

	int BorderA;
	int BorderB;


	printf("Enter start boundaries:\n ");

	scanf_s("%d", &BorderA);

	printf("Enter end boundaries:\n ");

	scanf_s("%d", &BorderB);

	for (int i = BorderA; i < BorderB; i++) {

		for (int j = BorderA; j < BorderB; j++) {


			s = i;
			t = j;

			c = (s*a) + (t*b);

			
			if (c == gcd) {

				


					printf("The Bezout coefficients of %d, %d are: %d, %d\n", a, b, s, t);
				
			}

			




		}
	}


}