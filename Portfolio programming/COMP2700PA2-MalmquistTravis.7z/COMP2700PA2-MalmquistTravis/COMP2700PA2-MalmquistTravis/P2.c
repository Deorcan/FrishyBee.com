#include <stdio.h>

int a = 0;
int b = 0;
int n = 0;
int x = 0;

void main() {

	printf("Enter integers: ");

	scanf_s("%d %d %d", &a, &b, &n);

	if (b*-1 <= 0) {


		while (b > n)
		{
			b = -n;


		}
	}
	else if (b*-1 >= 0) {

		while (b < n) {

			b = +n;
		}

	}

	x = b / a;

	if (a*x == b ) {
		printf("%d mod %d", x, x + 1);

	}
	else {

		printf("No solution");
	}

	int input = _getch();
}