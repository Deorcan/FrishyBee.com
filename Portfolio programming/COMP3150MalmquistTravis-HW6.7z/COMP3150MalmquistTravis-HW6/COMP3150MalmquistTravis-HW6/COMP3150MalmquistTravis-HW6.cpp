// COMP3150MalmquistTravis-HW6.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

							//Travis Malmquist
#include "pch.h"
#include <iostream>
#include "Employee.h"
using namespace std;
int main()
{

	string FirstName,LastName;
	double MonthlySalary;

	//Employee Person("Travis", "Malmquist", 3.5); //Me.

	cout << "Enter first name: ";

	cin >> FirstName;

	cout << "Enter last name: ";

	cin >> LastName;

	cout << "Enter Monthly salary: ";

	cin >> MonthlySalary;

	Employee Person(FirstName, LastName, MonthlySalary);


	Person.displaymessage(); //display message
}

