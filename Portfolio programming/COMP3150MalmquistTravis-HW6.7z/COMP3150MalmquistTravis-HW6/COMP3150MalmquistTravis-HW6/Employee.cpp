#include "pch.h"
#include "Employee.h"
#include<iostream>
#include<string>
using namespace std;
Employee::Employee(std::string Fname,std::string Lname,double Sal) //constructor
{
	setFirst_Name(Fname);
	setLast_Name(Lname);
	setMonthly_Salary(Sal);
}

//setters and getters:

void Employee::setFirst_Name(std::string F) {

	First_Name = F;
}

std::string Employee::getFirst_Name()const {

	return First_Name;
}

void Employee::setLast_Name(std::string L) {

	Last_Name = L;
}

std::string Employee::getLast_Name()const {

	return Last_Name;
}

void Employee::setMonthly_Salary(double MS) {

	Monthly_Salary = MS;

}

double Employee::getMonthly_Salary()const {

	return Monthly_Salary;
}

//view message

void Employee::displaymessage() {

	cout  << getFirst_Name() << " " << getLast_Name()
		<< "'s monthly salary is " << getMonthly_Salary() << endl;

}