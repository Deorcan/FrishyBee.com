#pragma once
#include<string>
class Employee
{
public:
	explicit Employee(std::string, std::string, double); //constructor

	//getters and setters

	void setFirst_Name(std::string); 

	std::string getFirst_Name()const;

	void setLast_Name(std::string);

	std::string getLast_Name()const;

	void setMonthly_Salary(double);

	double getMonthly_Salary()const;

	//view message

	void displaymessage();

private:

	std::string First_Name; //First name

	std::string Last_Name; // Last name

	double Monthly_Salary; //Salary
};

