#include <stdio.h>											//Travis Malmquist

int main(void) {

	int Nmbr, MAX_Numbr=0, count = 0; //Nmbr is the number used for the scanner or current number
	//, MAX_Numbr is the max. number
	//count is the counter

	while (count < 10) { //counter max

		printf("Enter a positive Number: \n");

		scanf_s("%d", &Nmbr); //Number input

		//printf("%d\n", Nmbr); //debugging

		if (Nmbr > MAX_Numbr) { //if current number is larger than the maximum number

			MAX_Numbr = Nmbr; //the maximum number becomes the current number

		}
		count++;
	}
	printf("Max number is: %d", MAX_Numbr); //prints max number

	
}