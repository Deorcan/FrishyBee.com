															//Travis Malmquist
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SUITS 4
#define FACES 13
#define CARDS 52

void ShuffleAndDeal(unsigned int wDeck[][FACES], const char *wFace[], const char *wSuit[]);

main(void) {
	
	unsigned int deck[SUITS][FACES] = { 0 };
	
	srand(time(NULL));
	
	const char *suit[SUITS] = { "Hearts","Diamonds","Clubs","Spades" };
	
	const char *face[FACES] = { "Ace","Deuce","Three","Four","Five","Six","Seven","Eight",
		"Nine","Ten","Jack","Queen","King" };
	
	printf("Shufflin' N' Dealin'... \n\n");

	ShuffleAndDeal(deck, face, suit);

	scanf_s("%d", deck);

}

void ShuffleAndDeal(unsigned int wDeck[][FACES], const char * wFace[], const char * wSuit[])
{
	for (size_t card = 1; card <= CARDS; ++card) {

		size_t row;
		size_t column;
		do {
			
			row = rand() % SUITS;
			column = rand() % FACES;


		} while (wDeck[row][column] = 0);
	
		wDeck[row][column] = card;


	}
	int tiny = 1; //number count of cards
	
		for (size_t row = 0; row < SUITS; row++)
		{
			for (size_t column = 0; column < FACES; column++)
			{

				if (tiny!=53) {
					
					if (tiny % 2 != 0) { //if tiny is odd

						printf("%d. %s of %-10s", tiny, wFace[column], wSuit[row]);

					}
					if(tiny % 2 == 0 ) { //if tiny is even

						printf("\t%d. %s of %s\n", tiny, wFace[column], wSuit[row]);
					}
						tiny++;
					
				}


			}
		}

	}


