#include <stdio.h>

																							//Travis Malmquist
unsigned long long int Fibo(unsigned int n) { 
	
	unsigned long long int result=0, Nmbr1=1, Nmbr2=0; 

	for (int i = 0; i <= n; i++) { //looping through till i equals n


		//printf("%d\n", result); //debugging

		Nmbr2 = result + Nmbr1; 

		result = Nmbr1;

		Nmbr1 = Nmbr2;

	}

	

	return result;

}



int main(void) {

	int x;

	printf("Enter the nth number in the Fibonacci series: ");

	scanf_s("%d", &x); 

	printf("The %dth number in the Fibonacci series is: %d", x, Fibo(x)); 
	
	
}